#-*-encoding:utf-8 -*-
from django.shortcuts import render_to_response
from django.http import HttpResponseRedirect
from django.http import HttpResponse,Http404
from game.models import Host
from django.views.decorators.csrf import csrf_exempt
import subprocess
import datetime
@csrf_exempt
def hostinfo(req):
    if req.method == "POST":
        ip = req.POST.get('ip')
        memory = req.POST.get('memory')
        system = req.POST.get('system')
        timezone = req.POST.get('timezone')
        disk = req.POST.get('disk')
        time = datetime.datetime.now()
        host =Host()
        host.ip = ip
        host.memory = memory
        host.system = system
        host.timezone = timezone
        host.disk = disk
        host.time = time
        host.save()
        return HttpResponse("ok")
    else:
        return HttpResponse("no data")
@csrf_exempt
def search(request):
    errors = []
    if 'IP' in request.GET:
        ip = request.GET['IP']
        ntp = request.GET['ntp']
        print "ip = %s" %ip
        restart = request.GET['restart']
        if not ip:
            errors.append('Enter IP')
        elif len(ip)> 100:
            errors.append('Please enter at most 100 character')
        elif ntp != "None" and restart == "YES":
                subprocess.call('python /root/python_dir/push_file.py -n %s -r -H %s' %(ntp,ip),shell=True)
                return HttpResponseRedirect('/admin/game/host/')
        elif ntp != "None" and restart =="NO":
                subprocess.call('python /root/python_dir/push_file.py -n %s -H %s' %(ntp,ip),shell=True)
                return HttpResponseRedirect('/admin/game/host/')
        elif ntp == "None" and restart =="YES":
                subprocess.call('python /root/python_dir/push_file.py -r -H %s' %ip,shell=True)
                return HttpResponseRedirect('/admin/game/host/')
        elif ntp =="None" and restart =="NO":
                subprocess.call('python /root/python_dir/push_file.py -H %s' %ip,shell=True)
                return HttpResponseRedirect('/admin/game/host/')
        else:
            return HttpResponseRedirect('/contact/us')
    return render_to_response('test.html',{'errors':errors})
@csrf_exempt
def search_form(request):
    return render_to_response('index.html')
@csrf_exempt
def contact(request):
    return HttpResponse("执行完成，请到后台查看")

