from django.contrib import admin
from game.models import Host
class HostAdmin(admin.ModelAdmin):
    list_display=[
            'ip',
            'system',
            'timezone',
            'memory', 
            'disk',
            'time',
        ]
admin.site.register(Host,HostAdmin)

# Register your models here.
