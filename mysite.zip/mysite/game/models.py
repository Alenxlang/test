from __future__ import unicode_literals
from django.db import models
class Host(models.Model):
    ip = models.CharField(max_length=50)
    system = models.CharField(max_length=50)
    timezone = models.CharField(max_length=50)
    memory = models.CharField(max_length=50)
    disk = models.CharField(max_length=300,null=True,blank=True)
    time = models.CharField(max_length=100,null=True,blank=True)
